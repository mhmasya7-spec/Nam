package com.example.platehunter

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Handler
import android.os.Looper
import android.util.Base64
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import kotlin.math.min
import kotlin.math.sqrt

/**
 * ChatGPT (OpenAI Realtime) live transcription over WebSocket, model gpt-live-transcribe.
 * - Captures 48 kHz mono, down-samples to 24 kHz PCM16 (what the API expects), ~100 ms chunks.
 * - Text arrives as incremental "delta" events; they are passed on as text fragments.
 * - After ~1 s of silence an input_audio_buffer.commit is sent so items stay short.
 * - Reconnects automatically after network failures and every ~55 minutes (session limit).
 * API keys should be proxied by a backend for public releases.
 */
class ChatGptLiveSpeech(private val onText: (String, Boolean) -> Unit, private val onStatus: (String) -> Unit) {
    companion object {
        const val MODEL = "gpt-live-transcribe"
        private const val CAPTURE_RATE = 48000
        private const val CHUNK_SAMPLES_IN = 4800 // 100 ms @ 48 kHz
        private const val ROTATE_MS = 55L * 60 * 1000
        private const val SILENCE_COMMIT_MS = 1000L
        private const val VOICE_RMS = 700.0
    }

    private val client = OkHttpClient.Builder().readTimeout(0, TimeUnit.MILLISECONDS).pingInterval(20, TimeUnit.SECONDS).build()
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var running = false
    @Volatile private var ready: WebSocket? = null
    private var apiKey = ""
    private var recorder: AudioRecord? = null
    private var audioThread: Thread? = null
    private var failures = 0
    private var minimal = false // retry without languages/keywords if the server rejects them
    private var announced = false
    private val gotDelta = HashSet<String>()
    private val rotate = Runnable { if (running) try { ready?.close(1000, "rotate") } catch (_: Exception) {} }

    fun start(key: String) {
        if (key.isBlank()) { onStatus("أدخل مفتاح OpenAI من الإعدادات"); return }
        if (running) return
        val min = AudioRecord.getMinBufferSize(CAPTURE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (min <= 0) { onStatus("تسجيل الصوت غير مدعوم على هذا الجهاز"); return }
        apiKey = key; failures = 0; minimal = false; announced = false
        try {
            val r = AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, CAPTURE_RATE,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min, CHUNK_SAMPLES_IN * 4))
            if (r.state != AudioRecord.STATE_INITIALIZED) { onStatus("تعذر تهيئة الميكروفون"); r.release(); return }
            recorder = r; running = true; r.startRecording()
        } catch (e: Exception) { onStatus("خطأ في تشغيل الصوت: ${e.message}"); stop(); return }
        audioThread = Thread {
            val inBuf = ShortArray(CHUNK_SAMPLES_IN)
            val r = recorder
            var speaking = false
            var lastVoice = 0L
            while (running && r != null) {
                var got = 0
                while (running && got < inBuf.size) {
                    val n = try { r.read(inBuf, got, inBuf.size - got) } catch (_: Exception) { -1 }
                    if (n < 0) { got = -1; break }
                    got += n
                }
                if (got <= 0) break
                val samples = got / 2
                val out = ByteArray(samples * 2)
                var sumSq = 0.0
                for (i in 0 until samples) {
                    val v = (inBuf[2 * i] + inBuf[2 * i + 1]) / 2
                    out[2 * i] = (v and 0xFF).toByte(); out[2 * i + 1] = ((v shr 8) and 0xFF).toByte()
                    sumSq += v.toDouble() * v
                }
                val ws = ready ?: continue // dropped while (re)connecting
                ws.send(JSONObject().put("type", "input_audio_buffer.append")
                    .put("audio", Base64.encodeToString(out, 0, out.size, Base64.NO_WRAP)).toString())
                val rms = if (samples > 0) sqrt(sumSq / samples) else 0.0
                val now = System.currentTimeMillis()
                if (rms > VOICE_RMS) { lastVoice = now; speaking = true }
                else if (speaking && now - lastVoice > SILENCE_COMMIT_MS) {
                    ws.send("""{"type":"input_audio_buffer.commit"}"""); speaking = false
                }
            }
        }.apply { name = "PlateHunterChatGptAudio"; start() }
        openSocket()
    }

    private fun sessionUpdate(): String {
        val tr = JSONObject().put("model", MODEL).put("delay", "low")
        if (!minimal) {
            tr.put("languages", JSONArray().put("ar"))
            tr.put("keywords", JSONArray(PlateParser.letterNames + listOf("وانيت", "تاكسي", "نقل", "ميكروباص", "يامه")))
        }
        return JSONObject().put("type", "session.update").put("session", JSONObject()
            .put("type", "transcription")
            .put("audio", JSONObject().put("input", JSONObject()
                .put("format", JSONObject().put("type", "audio/pcm").put("rate", 24000))
                .put("transcription", tr)))).toString()
    }

    private fun openSocket() {
        if (!running) return
        if (!announced) onStatus("جاري الاتصال بـ ChatGPT Live…")
        val request = Request.Builder()
            .url("wss://api.openai.com/v1/realtime?intent=transcription")
            .header("Authorization", "Bearer $apiKey")
            .build()
        client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                failures = 0
                webSocket.send(sessionUpdate())
                ready = webSocket
                main.removeCallbacks(rotate); main.postDelayed(rotate, ROTATE_MS)
            }
            override fun onMessage(webSocket: WebSocket, text: String) = handle(webSocket, text)
            override fun onMessage(webSocket: WebSocket, bytes: ByteString) = handle(webSocket, bytes.utf8())
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                val cur = ready
                if (cur != null && cur !== webSocket) return
                if (cur === webSocket) ready = null
                if (!running) return
                failures++
                val code = response?.code
                if (code == 400 || code == 401 || code == 403 || failures > 30) {
                    onStatus("تعذر اتصال ChatGPT Live: " + (if (code == 401) "مفتاح OpenAI غير صحيح" else (t.message ?: code?.toString() ?: "تحقق من الإنترنت")))
                    stop(); return
                }
                onStatus("انقطع ChatGPT Live — إعادة الاتصال…")
                main.postDelayed({ if (running && ready == null) openSocket() }, min(1000L * failures, 5000L))
            }
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                if (ready === webSocket) {
                    ready = null
                    if (running) main.postDelayed({ if (running && ready == null) openSocket() }, 500)
                }
            }
        })
    }

    private fun handle(ws: WebSocket, raw: String) {
        val o = try { JSONObject(raw) } catch (_: Exception) { return }
        when (o.optString("type")) {
            "session.created", "session.updated" -> if (!announced) { announced = true; onStatus("متصل بـ ChatGPT Live — الاستماع مباشر") }
            "conversation.item.input_audio_transcription.delta" -> {
                val d = o.optString("delta")
                if (d.isNotEmpty()) {
                    if (gotDelta.size > 200) gotDelta.clear()
                    gotDelta.add(o.optString("item_id")); onText(d, true)
                }
            }
            "conversation.item.input_audio_transcription.completed" -> {
                // Use the full transcript only if no deltas were received for this item (avoids duplicates)
                if (!gotDelta.remove(o.optString("item_id"))) {
                    val t = o.optString("transcript")
                    if (t.isNotBlank()) onText(t, true)
                }
            }
            "error" -> {
                val err = o.optJSONObject("error")
                val msg = err?.optString("message").orEmpty(); val code = err?.optString("code").orEmpty()
                if (code.contains("commit", true) || msg.contains("commit", true) || msg.contains("buffer", true)) return // harmless
                if (!minimal) { // maybe rejected languages/keywords: retry once with the basic config
                    minimal = true; ws.send(sessionUpdate()); return
                }
                onStatus("ChatGPT Live: $msg")
            }
        }
    }

    fun stop() {
        running = false
        main.removeCallbacks(rotate)
        try { recorder?.stop() } catch (_: Exception) {}
        try { recorder?.release() } catch (_: Exception) {}
        recorder = null
        val ws = ready; ready = null
        try { ws?.close(1000, "user stopped") } catch (_: Exception) {}
        audioThread = null
    }
}
